from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.utils import timezone
from .models import Vehicle, Booking
from .forms import BookingForm
from . import analytics  # Data science module (Pandas + Numpy + Seaborn + Matplotlib)

import base64
import io
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# -------------------------------------------------------
# 1️⃣ HOME PAGE + VEHICLE DISPLAY
# -------------------------------------------------------

def home(request):
    """Redirect user to vehicle list page."""
    return redirect('rentals:vehicle_list')


def vehicle_list(request):
    """Displays all available vehicles."""
    vehicles = Vehicle.objects.all()
    return render(request, 'rentals/vehicle_list.html', {'vehicles': vehicles})


def vehicle_detail(request, pk):
    """Displays details of a single vehicle."""
    vehicle = get_object_or_404(Vehicle, pk=pk)
    return render(request, 'rentals/vehicle_detail.html', {'vehicle': vehicle})


# -------------------------------------------------------
# 2️⃣ BOOKING SYSTEM
# -------------------------------------------------------

@login_required
def book_vehicle(request, vehicle_id):
    """Allows user to book a vehicle."""
    vehicle = get_object_or_404(Vehicle, pk=vehicle_id)

    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.user = request.user
            booking.vehicle = vehicle
            booking.status = 'Booked'

            # Calculate total rental cost based on duration × rate
            duration_hours = (booking.end_time - booking.start_time).total_seconds() / 3600.0
            booking.total_cost = round(duration_hours * float(vehicle.rent_per_hour), 2)

            booking.save()
            return redirect('rentals:booking_detail', pk=booking.pk)
    else:
        form = BookingForm()

    return render(request, 'rentals/book_vehicle.html', {'form': form, 'vehicle': vehicle})


@login_required
def booking_detail(request, pk):
    """Shows details of a specific booking."""
    booking = get_object_or_404(Booking, pk=pk)
    return render(request, 'rentals/booking_detail.html', {'booking': booking})


@login_required
def my_bookings(request):
    """Lists all bookings made by the logged-in user."""
    bookings = Booking.objects.filter(user=request.user).order_by('-start_time')
    return render(request, 'rentals/my_bookings.html', {'bookings': bookings})


# -------------------------------------------------------
# 3️⃣ DATA ANALYTICS + VISUALIZATION (Pandas + Seaborn)
# -------------------------------------------------------

@login_required
def analytics_dashboard(request):
    """
    Analytics dashboard showing total bookings, revenue, 
    unique users, most popular vehicles, and Seaborn/Matplotlib charts.
    """
    bookings = Booking.objects.select_related('vehicle', 'user').all()

    if not bookings.exists():
        stats = {
            'total_bookings': 0,
            'total_revenue': 0,
            'unique_users': 0,
            'most_popular_vehicle': 'N/A'
        }
        chart = None
        return render(request, 'rentals/analytics_dashboard.html', {'stats': stats, 'chart': chart})

    # Convert bookings to DataFrame
    df = pd.DataFrame(list(bookings.values(
        'id', 'vehicle__name', 'user__username', 'total_cost', 'start_time', 'end_time'
    )))
    df.rename(columns={
        'vehicle__name': 'Vehicle',
        'user__username': 'User',
        'total_cost': 'Amount',
        'start_time': 'Start',
        'end_time': 'End'
    }, inplace=True)

    # Compute statistics
    stats = {
        'total_bookings': len(df),
        'total_revenue': df['Amount'].sum(),
        'unique_users': df['User'].nunique(),
        'most_popular_vehicle': df['Vehicle'].mode().values[0]
    }

    # Generate multiple visualizations
    plt.switch_backend('Agg')
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))

    # 1️⃣ Bookings per Vehicle
    sns.countplot(x='Vehicle', data=df, ax=axes[0, 0], palette="Set2")
    axes[0, 0].set_title('Bookings per Vehicle')
    axes[0, 0].tick_params(axis='x', rotation=45)

    # 2️⃣ Revenue per Vehicle
    revenue_per_vehicle = df.groupby('Vehicle')['Amount'].sum().reset_index()
    sns.barplot(x='Vehicle', y='Amount', data=revenue_per_vehicle, ax=axes[0, 1], palette="Set3")
    axes[0, 1].set_title('Revenue per Vehicle')
    axes[0, 1].tick_params(axis='x', rotation=45)

    # 3️⃣ Bookings Over Time
    df['Start'] = pd.to_datetime(df['Start'])
    bookings_over_time = df.groupby(df['Start'].dt.date)['id'].count().reset_index()
    bookings_over_time.columns = ['Date', 'Bookings']
    sns.lineplot(x='Date', y='Bookings', data=bookings_over_time, ax=axes[1, 0], marker="o")
    axes[1, 0].set_title('Bookings Over Time')
    axes[1, 0].tick_params(axis='x', rotation=45)

    # 4️⃣ Bookings per User
    user_counts = df['User'].value_counts().reset_index()
    user_counts.columns = ['User', 'Bookings']
    sns.barplot(x='User', y='Bookings', data=user_counts, ax=axes[1, 1], palette="Set1")
    axes[1, 1].set_title('Bookings per User')
    axes[1, 1].tick_params(axis='x', rotation=45)

    plt.tight_layout()
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    chart = base64.b64encode(buffer.getvalue()).decode('utf-8')
    plt.close(fig)

    return render(request, 'rentals/analytics_dashboard.html', {'stats': stats, 'chart': chart})


@login_required
def bookings_table(request):
    """
    Displays all booking data as a Pandas-generated HTML table.
    """
    df = analytics.bookings_dataframe()
    if df is None or df.empty:
        table_html = "<p style='color:red;'>No booking data available.</p>"
    else:
        table_html = df.to_html(classes="table table-striped", index=False)
    return render(request, 'rentals/bookings_table.html', {'table_html': table_html})


@login_required
def bookings_json(request):
    """
    Exports all bookings as JSON — useful for APIs and datasets.
    """
    df = analytics.bookings_dataframe()
    if df is None or df.empty:
        return JsonResponse({'bookings': []})

    df['start_time'] = df['start_time'].astype(str)
    df['end_time'] = df['end_time'].astype(str)
    data = df.to_dict(orient='records')
    return JsonResponse({'bookings': data})


@login_required
def download_bookings_csv(request):
    """
    Download all booking records as CSV — for analysis in Excel/Pandas.
    """
    csv_bytes = analytics.export_bookings_csv()
    response = HttpResponse(csv_bytes, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="bookings_export.csv"'
    return response
