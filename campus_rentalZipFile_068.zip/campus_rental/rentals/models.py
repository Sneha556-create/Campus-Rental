from django.db import models

# Create your models here.
from django.db import models
from django.conf import settings
from decimal import Decimal

class Vehicle(models.Model):
    VEHICLE_TYPE_CHOICES = [('SCOOTY','Scooty'), ('CAR','Car')]
    name = models.CharField(max_length=100)
    vehicle_type = models.CharField(max_length=10, choices=VEHICLE_TYPE_CHOICES)
    number_plate = models.CharField(max_length=20, unique=True)
    rent_per_hour = models.DecimalField(max_digits=7, decimal_places=2)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.name} ({self.number_plate})"


class Wallet(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    balance = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('500.00'))

    def __str__(self):
        return f"{self.user.username} wallet"


class Booking(models.Model):
    STATUS_CHOICES = [
        ('BOOKED','Booked'),
        ('ONGOING','Ongoing'),
        ('COMPLETED','Completed'),
        ('CANCELLED','Cancelled'),
    ]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    vehicle = models.ForeignKey(Vehicle, on_delete=models.PROTECT)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    total_cost = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='BOOKED')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Booking #{self.pk} - {self.user.username}"

