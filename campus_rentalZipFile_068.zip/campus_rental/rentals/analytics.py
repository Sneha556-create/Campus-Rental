import io
import base64
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from .models import Booking, Vehicle

# ------------- #
# DATA HANDLING #
# ------------- #

def bookings_dataframe():
    """Convert all bookings to a Pandas DataFrame."""
    data = list(Booking.objects.select_related('vehicle', 'user').values(
        'id', 'user__username', 'vehicle__name', 'start_time', 'end_time', 'total_cost', 'status'
    ))
    return pd.DataFrame(data)


def summary_stats():
    """Return key summary stats for dashboard."""
    df = bookings_dataframe()
    if df.empty:
        return {
            'total_bookings': 0,
            'total_revenue': 0,
            'most_popular_vehicle': 'No data',
            'unique_users': 0
        }

    stats = {
        'total_bookings': len(df),
        'total_revenue': round(df['total_cost'].sum(), 2),
        'unique_users': df['user__username'].nunique(),
        'most_popular_vehicle': df['vehicle__name'].mode()[0] if not df['vehicle__name'].empty else 'N/A'
    }
    return stats

# ------------------------- #
# VISUALIZATION (SEABORN)   #
# ------------------------- #

def plot_bookings_per_vehicle():
    """
    Create a beautiful Seaborn chart showing the number of bookings per vehicle.
    Returns a base64 image string to embed in HTML.
    """
    df = bookings_dataframe()
    if df.empty:
        return None

    plt.figure(figsize=(9, 5))
    sns.set_theme(style="whitegrid", palette="muted")

    # Bar plot: Vehicle vs Number of bookings
    chart = sns.countplot(
        data=df,
        x='vehicle__name',
        order=df['vehicle__name'].value_counts().index,
        palette='coolwarm'
    )

    plt.title('Number of Bookings per Vehicle', fontsize=14, weight='bold')
    plt.xlabel('Vehicle', fontsize=12)
    plt.ylabel('Bookings Count', fontsize=12)
    plt.xticks(rotation=30, ha='right')

    # Convert to base64 for HTML embedding
    buffer = io.BytesIO()
    plt.tight_layout()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    plt.close()

    graphic = base64.b64encode(image_png)
    graphic = graphic.decode('utf-8')
    return graphic


def dataframe_to_html_table(df):
    """Render DataFrame to HTML (Bootstrap styled)."""
    return df.to_html(classes='table table-striped table-bordered', index=False, justify='center')


def export_bookings_csv():
    """Export all bookings as CSV bytes."""
    df = bookings_dataframe()
    return df.to_csv(index=False).encode('utf-8')
