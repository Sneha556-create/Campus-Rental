from django.contrib import admin
from .models import Vehicle, Booking

# Custom admin homepage template (adds analytics button)
admin.site.index_template = 'admin/custom_index.html'

@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = ('name', 'vehicle_type')  # only fields that exist in your model
    search_fields = ('name', 'vehicle_type')
    list_filter = ('vehicle_type',)  # only valid fields

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('user', 'vehicle', 'start_time', 'end_time', 'status', 'total_cost')
    list_filter = ('status', 'start_time')
    search_fields = ('user__username', 'vehicle__name')

# Optional: Customize admin titles
admin.site.site_header = "Campus Rental System Admin"
admin.site.index_title = "Campus Rental Management"
admin.site.site_title = "Campus Rental Admin"
