from django.urls import path
from . import views

app_name = 'rentals'
urlpatterns = [
    path('', views.vehicle_list, name='vehicle_list'),
    path('vehicle/<int:pk>/', views.vehicle_detail, name='vehicle_detail'),
    path('book/<int:vehicle_id>/', views.book_vehicle, name='book_vehicle'),
    path('booking/<int:pk>/', views.booking_detail, name='booking_detail'),
    path('my_bookings/', views.my_bookings, name='my_bookings'),

    # Analytics
    path('analytics/', views.analytics_dashboard, name='analytics_dashboard'),
    path('analytics/download_csv/', views.download_bookings_csv, name='download_csv'),
    path('analytics/download_json/', views.bookings_json, name='download_json'),
    path('analytics/table/', views.bookings_table, name='bookings_table'),
]