from django import forms
from .models import Booking
from django.utils import timezone

class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['start_time', 'end_time']
        widgets = {
            'start_time': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'end_time': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        }

    def clean(self):
        data = super().clean()
        start = data.get('start_time')
        end = data.get('end_time')
        if start and end:
            if start >= end:
                raise forms.ValidationError("Start must be before end.")
            if start < timezone.now():
                raise forms.ValidationError("Start must be in the future.")
        return data
